#ifndef GLOBAL_JSON_CONTAINER_HPP
#define GLOBAL_JSON_CONTAINER_HPP
#include "util/json_container.hpp"
namespace osrm
{
    namespace json = osrm::util::json;
}
#endif

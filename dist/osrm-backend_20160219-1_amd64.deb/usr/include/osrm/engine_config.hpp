#ifndef GLOBAL_ENGINE_CONFIG_HPP
#define GLOBAL_ENGINE_CONFIG_HPP

#include "engine/engine_config.hpp"

namespace osrm
{
    using engine::EngineConfig;
}

#endif


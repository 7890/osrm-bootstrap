#ifndef GLOBAL_ROUTE_PARAMETERS_HPP
#define GLOBAL_ROUTE_PARAMETERS_HPP

#include "engine/route_parameters.hpp"

namespace osrm
{
    using engine::RouteParameters;
}

#endif

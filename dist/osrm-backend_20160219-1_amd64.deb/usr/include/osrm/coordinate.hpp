#ifndef GLOBAL_COORDINATE_HPP
#define GLOBAL_COORDINATE_HPP

#include "util/coordinate.hpp"

namespace osrm
{
    using util::FixedPointCoordinate;
}

#endif
